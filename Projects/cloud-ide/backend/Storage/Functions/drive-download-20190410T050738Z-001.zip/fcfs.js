var process=["Process1","Process2","Process3"];
var duration=[24,3,4];

var waitingtime=0;
var totalwait=0;
var turnaroundtime=duration[0];
console.log("Process\t\tDuration\tWaitingTime\tTurnaroundTime");
console.log("--------------------------------------------");
for(var i=0;i<process.length;i++){
  console.log(process[i]+"\t"+duration[i]+"\t"+waitingtime+"\t"+turnaroundtime);
  if(i!=(process.length-1)){
    waitingtime+=duration[i];
    totalwait+=waitingtime;
  }
  turnaroundtime+=duration[i+1];
}

console.log("Total waiting time="+waitingtime);
console.log("Average Waiting time="+(totalwait/process.length));
