var process=["Process1","Process2","Process3"];
var duration=[24,3,4];

for(var i=0;i<process.length;i++){
  for(var j=0;j<i;j++){
    if(duration[i]<duration[j]){
      t=duration[i];
      t1=process[i];
      duration[i]=duration[j];
      process[i]=process[j];
      duration[j]=t;
      process[j]=t1;
    }
  }
}

var waitingtime=0;
var totalwait=0;
var turnaroundtime=duration[0];
console.log("Process\t\tDuration\tWaitingTime\tTurnaroundTime");
console.log("--------------------------------------------");
for(var i=0;i<process.length;i++){
  console.log(process[i]+"\t"+duration[i]+"\t"+waitingtime+"\t"+turnaroundtime);
  if(i!=(process.length-1)){
    waitingtime+=duration[i];
    totalwait+=waitingtime;
  }
  turnaroundtime+=duration[i+1];
}

console.log("Total waiting time="+waitingtime);
console.log("Average Waiting time="+(totalwait/process.length));
