var process=['Process1','Process2','Process3'];
var priority=[3,1,2];

var duration=[24,3,4];

var t=0,t1,t2;
for(var i=0;i<process.length;i++){
  for(var j=0;j<i;j++){
    if(priority[i]<priority[j]){
      t=priority[i];
      t1=process[i];
      t2=duration[i];
      priority[i]=priority[j];
      process[i]=process[j];
      duration[i]=duration[j];
      priority[j]=t;
      process[j]=t1;
      duration[j]=t2;
    }
  }
}

var waitingtime=0;
var totalwait=0;
var turnaroundtime=duration[0];
console.log("Process\tPriority\tDuration\tWaitingTime\tTurnaroundTime");
console.log("--------------------------------------------");
for(var i=0;i<process.length;i++){
  console.log(process[i]+"\t"+priority[i]+"\t"+duration[i]+"\t"+waitingtime+"\t"+turnaroundtime);
  if(i!=(process.length-1)){
    waitingtime+=duration[i];
    totalwait+=waitingtime;
  }
  turnaroundtime+=duration[i+1];
}

console.log("Total waiting time="+waitingtime);
console.log("Average Waiting time="+(totalwait/process.length));
